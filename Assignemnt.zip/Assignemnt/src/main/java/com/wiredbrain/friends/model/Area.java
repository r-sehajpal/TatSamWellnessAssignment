package com.wiredbrain.friends.model;

import javax.persistence.*;

//Mapped Area class with entity annotation
//to set and get data

@Entity
@Table(name = "areas")
public class Area {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;
    private String area;

    public void setArea(String area){
        this.area = area;
    }
    public String getArea(){
        return this.area;
    }

    public void setId(int id){
        this.id = id;
    }

    public int getId(){
        return this.id;
    }
}
