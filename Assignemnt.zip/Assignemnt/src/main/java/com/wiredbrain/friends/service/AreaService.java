package com.wiredbrain.friends.service;

import com.wiredbrain.friends.model.Area;
import org.springframework.data.repository.CrudRepository;

//Area Service to communicate with SQL Driver
public interface AreaService extends CrudRepository<Area, Integer> {
}
