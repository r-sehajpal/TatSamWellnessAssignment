package com.wiredbrain.friends.service;

import com.wiredbrain.friends.model.UserData;
import org.springframework.data.repository.CrudRepository;

//UserData Service to communicate with SQL Driver
public interface UserDataService extends CrudRepository<UserData, Integer> {
    Iterable<UserData> findByName(String name);
}
