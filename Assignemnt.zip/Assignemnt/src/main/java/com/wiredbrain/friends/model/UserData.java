package com.wiredbrain.friends.model;

import javax.persistence.*;

//Mapped UserData class to entity annotation
//to set and get data

@Entity
@Table(name = "userpriority")
public class UserData {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    private String name;
    private int priority;
    private String area;
    private int rating;

    public void setId(int id){
        this.id = id;
    }
    public int getId(){
        return this.id;
    }

    public void setName(String name){
        this.name = name;
    }
    public String getName(){
        return this.name;
    }

    public void setPriority(int priority){
        this.priority = priority;
    }
    public int getPriority(){
        return this.priority;
    }

    public void setArea(String area){
        this.area = area;
    }
    public String getArea(){
        return this.area;
    }

    public void setRating(int rating){
        this.rating = rating;
    }
    public int getRating(){
        return this.rating;
    }
}
