package com.wiredbrain.friends.controller;

import com.wiredbrain.friends.model.Area;
import com.wiredbrain.friends.model.UserData;
import com.wiredbrain.friends.service.AreaService;
import com.wiredbrain.friends.service.UserDataService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

//Controller to handle HTTP requests
@RestController
public class PriorityController {

    @Autowired
    AreaService areaService;

    @Autowired
    UserDataService userDataService;


    //To add different areas
    @PutMapping("/areas/")
    Area addArea(@RequestBody Area area){
        return areaService.save(area);
    }

    //To get all the areas for which priority will be assigned
    @GetMapping("/areas")
    Iterable<Area> showArea(){
        return areaService.findAll();
    }

    //Get list of areas along with priority and rating based on name of user
    @GetMapping("/search")
    Iterable<UserData> viewByName(@RequestParam("name") String name){
        return userDataService.findByName(name);
    }

    //Add priority and rating for an area and user
    @PostMapping("/addPriority")
    UserData addPriority(@RequestBody UserData userData){
        return userDataService.save(userData);
    }
}
